<?php
    if($_POST['username'] && $_POST['password']){
        $pengguna = loginadmin($_POST['username'], $_POST['password']);
        if($pengguna){
             $_SESSION['pengguna'] = $_POST['username'];
            header("Location: /Pages/admin/pengaturan/pengaturan.php");
        }
        else {
            
            header("Location: /Pages/admin/index.php");
        }
    } else {
        header("Location: /pages/admin/index.php");
    }
?>