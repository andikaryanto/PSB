<?php
    deletepengguna($_GET['id']);
    header("location:/Pages/admin/pengguna/daftar.php");
?>