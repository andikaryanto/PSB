<?php
    
if($peserta){
    header("Location: /Pages/pesertaditerima.php");
} else {
    header("Location: /Pages/pesertaditolak.php");
}

?>