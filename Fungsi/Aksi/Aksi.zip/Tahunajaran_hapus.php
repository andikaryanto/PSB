<?php

    $tahun = ambilhanyatahunajaran("WHERE Id = {$_GET['id']}");
    if($tahun['Aktif'])
        die('Tidak bisa hapus tahun ajaran yang aktif');
    
    
    deletetahunajaran($_GET['id']);
    header("location:/Pages/admin/tahunajaran/daftar.php");
?>