<?php
    $_SESSION['pengguna'] = null;
    header("Location: /Pages/admin/index.php");